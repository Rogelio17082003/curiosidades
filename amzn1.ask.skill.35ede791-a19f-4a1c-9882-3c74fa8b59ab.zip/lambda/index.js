/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');

const i18n = require('i18next');
const sprintf = require('i18next-sprintf-postprocessor'); 

const languageStrings = {
    en: {
        translation: {
            WELCOME_MESSAGE: "Hi Rogelio! thanks for using programming trivia, to start you can say: mention: tell me a fun fact about programming... or if you want to stop me just say, Cancel! ...so how can I help you?",
            GET_FRASES_MSG: "A curious fact is...",
            HELLO_MESSAGE: "hello world Rogelio",
            HELP_MESSAGE: "You can say hello to me! How can I help Rogelio?",
            GOODBYE_MESSAGE: "Goodbye Rogelio!",
            REFLECTOR_MESSAGE: "You just triggered %s",
            FALLBACK_MESSAGE: "Sorry, I don't know about that. Please try again.",
            ERROR_MESSAGE: "Sorry, there was an error. Please try again.",
            GET_MESSAGE2: "you can ask for another fun fact... mention: explain to me an important fact about programming... or if you want to stop me just say, Cancel! ... How can I help you?",
            FRASES_DATA: [
                "The first computer programmer was Ada Lovelace, who created an algorithm for Charles Babbage's early mechanical general-purpose computer, the Analytical Engine.",
                "Python, a high-level programming language, was named after the British comedy series 'Monty Python’s Flying Circus'.",
                "The first high-level programming language was Fortran, developed in the 1950s for scientific and engineering applications.",
                "'Hello, World!' is often the first program written by beginners learning a new programming language.",
                "The JavaScript language was created in just 10 days by Brendan Eich in May 1995.",
                "There are over 700 different programming languages, including well-known ones like C, C++, Java, and Python.",
                "The C programming language, developed in the early 1970s, is the foundation for many modern programming languages like C++, C#, and Java.",
                "Open-source software, which allows anyone to inspect, modify, and enhance the code, includes popular projects like Linux, Apache, and Mozilla Firefox."
            ]
        }
    },
    es: {
        translation: {
            WELCOME_MESSAGE: "¡Hola Rogelio! Gracias por usar trivia de programación. Para empezar puedes decir: menciona: dime un dato curioso sobre la programación... o si quieres que me detenga, solo di, ¡Cancelar! ... ¿Cómo puedo ayudarte?",
            GET_FRASES_MSG: "Un dato curioso es...",
            HELLO_MESSAGE: "hola mundo Rogelio",
            HELP_MESSAGE: "¡Puedes saludarme! ¿Cómo puedo ayudarte, Rogelio?",
            GOODBYE_MESSAGE: "Adiós, Rogelio!",
            REFLECTOR_MESSAGE: "Acabas de activar %s",
            FALLBACK_MESSAGE: "Lo siento, no sé sobre eso. Por favor, inténtalo de nuevo.",
            ERROR_MESSAGE: "Lo siento, hubo un error. Por favor, inténtalo de nuevo.",
            GET_MESSAGE2: "puedes pedir otro dato curioso... menciona: explícamelo un hecho importante sobre la programación... o si quieres que me detenga, solo di, ¡Cancelar! ... ¿Cómo puedo ayudarte?",
            FRASES_DATA: [
                "La primera programadora de computadoras fue Ada Lovelace, quien creó un algoritmo para la primera computadora mecánica de uso general, el Motor Analítico de Charles Babbage.",
                "Python, un lenguaje de programación de alto nivel, fue nombrado así por la serie de comedia británica 'Monty Python’s Flying Circus'.",
                "El primer lenguaje de programación de alto nivel fue Fortran, desarrollado en la década de 1950 para aplicaciones científicas e ingenieriles.",
                "'¡Hola, Mundo!' es a menudo el primer programa que escriben los principiantes al aprender un nuevo lenguaje de programación.",
                "El lenguaje JavaScript fue creado en solo 10 días por Brendan Eich en mayo de 1995.",
                "Hay más de 700 lenguajes de programación diferentes, incluidos algunos bien conocidos como C, C++, Java y Python.",
                "El lenguaje de programación C, desarrollado a principios de la década de 1970, es la base de muchos lenguajes de programación modernos como C++, C# y Java.",
                "El software de código abierto, que permite a cualquiera inspeccionar, modificar y mejorar el código, incluye proyectos populares como Linux, Apache y Mozilla Firefox."
            ]
        }
    }
};

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const speakOutput = requestAttributes.t('WELCOME_MESSAGE');
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const FrasesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'FrasesIntent';
    },
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const frasesArray = requestAttributes.t('FRASES_DATA');
        
        const frasesIndice = Math.floor(Math.random() * frasesArray.length);
        const randomFrase = frasesArray[frasesIndice];
        const speakOutput = `${requestAttributes.t('GET_FRASES_MSG')} ${randomFrase} ... ${requestAttributes.t('GET_MESSAGE2')}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


const HelloWorldIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'HelloWorldIntent';
    },
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const speakOutput = requestAttributes.t('HELLO_MESSAGE');

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const speakOutput = requestAttributes.t('HELP_MESSAGE');

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const speakOutput = requestAttributes.t('GOODBYE_MESSAGE');

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    
    handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        const speakOutput = requestAttributes.t('FALLBACK_MESSAGE');

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
 

const LoggingRequestInterceptor = {
    process(handlerInput) {
        console.log(`Incoming request: ${JSON.stringify(handlerInput.requestEnvelope.request)}`);
    }
};

const LoggingResponseInterceptor = {
    process(handlerInput, response) {
      console.log(`Outgoing response: ${JSON.stringify(response)}`);
    }
};

const LocalizationInterceptor = {
  process(handlerInput) {
    const localizationClient = i18n.use(sprintf).init({
      lng: handlerInput.requestEnvelope.request.locale,
      fallbackLng: 'en',
      overloadTranslationOptionHandler: sprintf.overloadTranslationOptionHandler,
      resources: languageStrings,
      returnObjects: true
    });

    const attributes = handlerInput.attributesManager.getRequestAttributes();
    attributes.t = function (...args) {
      return localizationClient.t(...args);
    }
  }
}


exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        FrasesIntentHandler,
        HelloWorldIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .addRequestInterceptors(
        LocalizationInterceptor,
        LoggingRequestInterceptor)
    .addResponseInterceptors(
        LoggingResponseInterceptor)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();